﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Timers;
/* Program: Bouncy Ball Class - BouncyBall.cs 
 * Author: Mike Dean
 * Date: April 17 2015
 */
namespace BouncingBall
{
    class BouncyBall
    {
        // X Coordinate for the ball.
        private int xCoord;

        //Getter/Setter for xCoord
        public int XCoord
        {
            get { return xCoord; }
            set { xCoord = value; }
        }

        // Y Coordinate for the ball.
        private int yCoord;

        //Getter/Setter for yCoord
        public int YCoord
        {
            get { return yCoord; }
            set { yCoord = value; }
        }

        // Defined size of the ball.
        private int defSize;

        //Getter/Setter for defSize
        public int DefSize
        {
            get { return defSize; }
            set { defSize = value; }
        }
        // Velocity in the X-Axis
        private int xVelocity;

        //Getter/Setter for xVelocity.
        public int XVelocity
        {
            get { return xVelocity; }
            set { xVelocity = value; }
        }
        // Velocity in the Y-Axis.
        private int yVelocity;

        //Getter/Setter for yVelocity.
        public int YVelocity
        {
            get { return yVelocity; }
            set { yVelocity = value; }
        }

        // Max X Boundary for the Ball.
        private int xBound;
        // Max Y Boundary for the Ball.
        private int yBound;
        // Min X Boundary for the Ball.
        private int xMin;
        // Min Y Boundary for the Ball.
        private int yMin;

        // Pen used to draw outline.
        private Pen myPen;

        // Brush used to fill the ball.
        private Brush myBrush;

        // Graphics for use inside the ball class.
        private Graphics bGraphics;

        // instance of the main form to grab bound values.
        private frmBouncingBall bForm;


        public BouncyBall(Graphics g)
        {
            bForm = new frmBouncingBall();
            xCoord = 0;
            yCoord = 0;
            defSize = 50;
            xVelocity = 10;
            yVelocity = 10;
            // Making sure the ball stays within bounds of x and y.
            xBound = bForm.pnlBounce.Size.Width -50;
            yBound = bForm.pnlBounce.Size.Height -50;
            xMin = 0;
            yMin = 0;
            bGraphics = g;
            // default values for the pen and brush.
            myPen = new Pen(Color.Black, 1);
            myBrush = new SolidBrush(Color.Red);
        }

        // Default method to draw the ball, keep the ball a circle.
        public void drawBall()
        {
            bGraphics.DrawEllipse(myPen, xCoord, yCoord, defSize, defSize);
            bGraphics.FillEllipse(myBrush, xCoord, yCoord, defSize,defSize);
            

        }

        public void ballBounce()
        {
            //Each time the ball is drawn, clear the area for the new ball.
            bGraphics.Clear(Color.DarkGray);

                // Add the velocity in each of the x,y axis 
            // and draw the new ball at the new location
                xCoord = xCoord + xVelocity;
                yCoord = yCoord + yVelocity;     
                drawBall();
        
				// Collision with walls - Check if within the bounds.
				if (xCoord>xBound){xVelocity=-xVelocity;}
				if (xCoord< xMin){xVelocity=-xVelocity;}

				if (yCoord>yBound){yVelocity=-yVelocity;}
				if (yCoord<-yMin){yVelocity=-yVelocity;}


        }

        // Restyle the fill of the ball with a new specified color.s
        public void restyle(Color nuColor)
        {
            myBrush = new SolidBrush(nuColor);
        }
    }
}
