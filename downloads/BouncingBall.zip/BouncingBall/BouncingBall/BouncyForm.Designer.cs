﻿namespace BouncingBall
{
  partial class frmBouncingBall
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
            this.components = new System.ComponentModel.Container();
            this.pnlBounce = new System.Windows.Forms.Panel();
            this.btnBounce = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.grpBallOp = new System.Windows.Forms.GroupBox();
            this.numSize = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.btnChangeColor = new System.Windows.Forms.Button();
            this.lblDirection = new System.Windows.Forms.Label();
            this.cmbDirection = new System.Windows.Forms.ComboBox();
            this.lblSpeed = new System.Windows.Forms.Label();
            this.numSpeed = new System.Windows.Forms.NumericUpDown();
            this.colorDialog = new System.Windows.Forms.ColorDialog();
            this.btnSet = new System.Windows.Forms.Button();
            this.BouncyToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.helpProvider = new System.Windows.Forms.HelpProvider();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.helpToolStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.contentTool = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutTool = new System.Windows.Forms.ToolStripMenuItem();
            this.grpBallOp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSpeed)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlBounce
            // 
            this.pnlBounce.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlBounce.BackColor = System.Drawing.Color.DarkGray;
            this.pnlBounce.Location = new System.Drawing.Point(10, 138);
            this.pnlBounce.Margin = new System.Windows.Forms.Padding(4);
            this.pnlBounce.Name = "pnlBounce";
            this.pnlBounce.Size = new System.Drawing.Size(842, 366);
            this.pnlBounce.TabIndex = 0;
            this.pnlBounce.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pnlBounce_MouseClick);
            // 
            // btnBounce
            // 
            this.btnBounce.Location = new System.Drawing.Point(517, 512);
            this.btnBounce.Margin = new System.Windows.Forms.Padding(4);
            this.btnBounce.Name = "btnBounce";
            this.btnBounce.Size = new System.Drawing.Size(147, 36);
            this.btnBounce.TabIndex = 1;
            this.btnBounce.Text = "Bounce";
            this.btnBounce.UseVisualStyleBackColor = true;
            this.btnBounce.Click += new System.EventHandler(this.btnBounce_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(705, 512);
            this.btnExit.Margin = new System.Windows.Forms.Padding(4);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(147, 36);
            this.btnExit.TabIndex = 2;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // grpBallOp
            // 
            this.grpBallOp.Controls.Add(this.btnSet);
            this.grpBallOp.Controls.Add(this.numSize);
            this.grpBallOp.Controls.Add(this.label1);
            this.grpBallOp.Controls.Add(this.btnChangeColor);
            this.grpBallOp.Controls.Add(this.lblDirection);
            this.grpBallOp.Controls.Add(this.cmbDirection);
            this.grpBallOp.Controls.Add(this.lblSpeed);
            this.grpBallOp.Controls.Add(this.numSpeed);
            this.grpBallOp.Location = new System.Drawing.Point(0, 31);
            this.grpBallOp.Name = "grpBallOp";
            this.grpBallOp.Size = new System.Drawing.Size(550, 100);
            this.grpBallOp.TabIndex = 3;
            this.grpBallOp.TabStop = false;
            this.grpBallOp.Text = "Ball Options";
            // 
            // numSize
            // 
            this.numSize.Location = new System.Drawing.Point(82, 61);
            this.numSize.Name = "numSize";
            this.numSize.Size = new System.Drawing.Size(120, 22);
            this.numSize.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "Size:";
            // 
            // btnChangeColor
            // 
            this.btnChangeColor.Location = new System.Drawing.Point(223, 28);
            this.btnChangeColor.Name = "btnChangeColor";
            this.btnChangeColor.Size = new System.Drawing.Size(120, 23);
            this.btnChangeColor.TabIndex = 4;
            this.btnChangeColor.Text = "Change Colour";
            this.btnChangeColor.UseVisualStyleBackColor = true;
            this.btnChangeColor.Click += new System.EventHandler(this.btnChangeColor_Click);
            // 
            // lblDirection
            // 
            this.lblDirection.AutoSize = true;
            this.lblDirection.Location = new System.Drawing.Point(220, 62);
            this.lblDirection.Name = "lblDirection";
            this.lblDirection.Size = new System.Drawing.Size(68, 17);
            this.lblDirection.TabIndex = 3;
            this.lblDirection.Text = "Direction:";
            // 
            // cmbDirection
            // 
            this.cmbDirection.FormattingEnabled = true;
            this.cmbDirection.Items.AddRange(new object[] {
            "Up",
            "Down",
            "Left",
            "Right"});
            this.cmbDirection.Location = new System.Drawing.Point(294, 58);
            this.cmbDirection.Name = "cmbDirection";
            this.cmbDirection.Size = new System.Drawing.Size(121, 24);
            this.cmbDirection.TabIndex = 2;
            this.cmbDirection.SelectedIndexChanged += new System.EventHandler(this.cmbDirection_SelectedIndexChanged);
            // 
            // lblSpeed
            // 
            this.lblSpeed.AutoSize = true;
            this.lblSpeed.Location = new System.Drawing.Point(7, 34);
            this.lblSpeed.Name = "lblSpeed";
            this.lblSpeed.Size = new System.Drawing.Size(53, 17);
            this.lblSpeed.TabIndex = 1;
            this.lblSpeed.Text = "Speed:";
            // 
            // numSpeed
            // 
            this.helpProvider.SetHelpKeyword(this.numSpeed, "Speed");
            this.helpProvider.SetHelpString(this.numSpeed, "This changes the speed of the ball. Click Set Values to see Result");
            this.numSpeed.Location = new System.Drawing.Point(82, 29);
            this.numSpeed.Name = "numSpeed";
            this.helpProvider.SetShowHelp(this.numSpeed, true);
            this.numSpeed.Size = new System.Drawing.Size(120, 22);
            this.numSpeed.TabIndex = 0;
            // 
            // btnSet
            // 
            this.btnSet.Location = new System.Drawing.Point(438, 34);
            this.btnSet.Name = "btnSet";
            this.btnSet.Size = new System.Drawing.Size(106, 49);
            this.btnSet.TabIndex = 7;
            this.btnSet.Text = "Set Values";
            this.BouncyToolTip.SetToolTip(this.btnSet, "Use when you have set new values for Speed and Size");
            this.btnSet.UseVisualStyleBackColor = true;
            this.btnSet.Click += new System.EventHandler(this.btnSet_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.helpToolStrip});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(868, 28);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // helpToolStrip
            // 
            this.helpToolStrip.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.contentTool,
            this.aboutTool});
            this.helpToolStrip.Name = "helpToolStrip";
            this.helpToolStrip.Size = new System.Drawing.Size(53, 24);
            this.helpToolStrip.Text = "Help";
            // 
            // contentTool
            // 
            this.contentTool.Name = "contentTool";
            this.contentTool.Size = new System.Drawing.Size(152, 24);
            this.contentTool.Text = "Content";
            this.contentTool.Click += new System.EventHandler(this.contentTool_Click);
            // 
            // aboutTool
            // 
            this.aboutTool.Name = "aboutTool";
            this.aboutTool.Size = new System.Drawing.Size(152, 24);
            this.aboutTool.Text = "About";
            this.aboutTool.Click += new System.EventHandler(this.aboutTool_Click);
            // 
            // frmBouncingBall
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(868, 561);
            this.Controls.Add(this.btnBounce);
            this.Controls.Add(this.grpBallOp);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.pnlBounce);
            this.Controls.Add(this.menuStrip1);
            this.HelpButton = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmBouncingBall";
            this.helpProvider.SetShowHelp(this, true);
            this.Text = "Bouncing Ball";
            this.Load += new System.EventHandler(this.frmBouncingBall_Load);
            this.grpBallOp.ResumeLayout(false);
            this.grpBallOp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSpeed)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Button btnBounce;
    private System.Windows.Forms.Button btnExit;
    internal System.Windows.Forms.Panel pnlBounce;
    private System.Windows.Forms.GroupBox grpBallOp;
    private System.Windows.Forms.Label lblDirection;
    private System.Windows.Forms.ComboBox cmbDirection;
    private System.Windows.Forms.Label lblSpeed;
    private System.Windows.Forms.NumericUpDown numSpeed;
    private System.Windows.Forms.NumericUpDown numSize;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Button btnChangeColor;
    private System.Windows.Forms.ColorDialog colorDialog;
    private System.Windows.Forms.Button btnSet;
    private System.Windows.Forms.ToolTip BouncyToolTip;
    private System.Windows.Forms.HelpProvider helpProvider;
    private System.Windows.Forms.MenuStrip menuStrip1;
    private System.Windows.Forms.ToolStripMenuItem helpToolStrip;
    private System.Windows.Forms.ToolStripMenuItem contentTool;
    private System.Windows.Forms.ToolStripMenuItem aboutTool;
  }
}

