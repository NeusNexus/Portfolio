﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
/* Program: Bouncy Ball Program - Main Form.
 * Author: Mike Dean
 * Date: April 17 2015
 */
namespace BouncingBall
{
  public partial class frmBouncingBall : Form
  {



    // Graphics area to drawn on.
    Graphics graPanel;
    // Instance of the BouncyBall Class
    BouncyBall ball;
    // Instance of the Timer.
    private Timer timer;
    // Color used to recolour the bouncy ball.
    private Color bColor;

    // Help file path.
    string strHelpPath = System.IO.Path.Combine(Application.StartupPath, "BouncyHelp.chm");

    public frmBouncingBall()
    {
      InitializeComponent();
        // Create graphics from pnlBounce.
        graPanel = pnlBounce.CreateGraphics();

        helpProvider.HelpNamespace = strHelpPath;
        
      
    }

    // each time the timer ticks, tell the ball to bounce around.
    private void timer_Tick(object sender, EventArgs e)
    {
       ball.ballBounce();
    }
      
    private void pnlBounce_MouseClick(object sender, MouseEventArgs e)
    {
      // Disable the timer so the ball stops moving.
      timer.Enabled = false;
       // Clear the graphics area so there is no trailing graphics.
      graPanel.Clear(pnlBounce.BackColor);
      // Set the X Value of the Ball to the current X Value of the Mouse Pointer.
      ball.XCoord = e.X;
      // Set the X Value of the Ball to the current X Value of the Mouse Pointer.
      ball.YCoord = e.Y;
        // draw the ball.
      ball.drawBall();
      
      
        
    }

    private void btnExit_Click(object sender, EventArgs e)
    {
      this.Close();
    }
    
     //Each time the Bounce button is clicked...
    private void btnBounce_Click(object sender, EventArgs e)
    {
        //Enable the timer,
        this.timer.Enabled = true;
        // Set the Interval to 25;
        this.timer.Interval = 25;
        //Set the timer_Tick event to occur each time the timer tics.
        this.timer.Tick += new System.EventHandler(this.timer_Tick);
        //start the timer.
        timer.Start();
    }

    private void btnChangeColor_Click(object sender, EventArgs e)
    {
        // Create the ColorDialog.
        ColorDialog Colour = new ColorDialog();

        // Show the Dialog.
        Colour.ShowDialog();

        //Get the color selected in the dialog.
        bColor = Colour.Color;

        // Restyle the bouncyball.
        ball.restyle(bColor);
    }

      //Each time the index of the combo box is changed.
    private void cmbDirection_SelectedIndexChanged(object sender, EventArgs e)
    {
        int index = cmbDirection.SelectedIndex;

        switch (index)
        {
             // Change direction to Up
            case 0:
                ball.YVelocity = -ball.YVelocity;
                break;
            case 1:
                // Change direction to Down.
                ball.YVelocity = -ball.YVelocity;
                break;
            // Change direction to Left
            case 2:
                ball.XVelocity = -ball.XVelocity;
                break;
            // Change direction to Right
            case 3:
                ball.XVelocity = -ball.XVelocity;
                break;


        }
    }
      // Set the speed and size values and change those values in the ball object.
    private void btnSet_Click(object sender, EventArgs e)
    {
        //If the speed has changed
        if (numSpeed.Value > 0)
        {
            ball.XVelocity = (int)numSpeed.Value;
            ball.YVelocity = (int)numSpeed.Value;
        }
        // If the size has changed.
        if (numSize.Value > 0)
        {
            ball.DefSize = (int)numSize.Value;
        }

    }

      //When the form loads, create the instance of the ball and create the timer.
    private void frmBouncingBall_Load(object sender, EventArgs e)
    {
        ball = new BouncyBall(graPanel);
        timer = new Timer();

        

    }

    private void aboutTool_Click(object sender, EventArgs e)
    {
        About About = new About();

        About.ShowDialog();
    }

    private void contentTool_Click(object sender, EventArgs e)
    {
        Help.ShowHelp(this, helpProvider.HelpNamespace, HelpNavigator.TableOfContents);
    }
  }
}
