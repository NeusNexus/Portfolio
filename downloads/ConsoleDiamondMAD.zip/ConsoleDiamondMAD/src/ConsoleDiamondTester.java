
public class ConsoleDiamondTester {

	/**Tester for the Console Diamond.
	 * Purpose: sets the size of the diamond 
	 * to the integer returned by inputsize() and 
	 * output the diamond.
	 * @param args
	 */ 
	public static void main(String[] args) {
	
		MyConsole myCon = new MyConsole();
		Diamond diamond = new Diamond();
		diamond.setSize(myCon.inputSize());
		myCon.outputDiamond(diamond.makeDiamond());

	}

}
