
/*
 * Draw a Diamond - Exercise 6.16 in BJ5
 * K Stewart Feb 2014
 * Edited by Mike Dean March 17 2014,
 * Updated to seperate System.in/out to MyConsole.java.
 */

public class Diamond {
	private static final int MINSIZE = 1;
	private static final int MAXSIZE = 10;
	private static final String ASTERISK = "*";
	private static final String SPACE = " ";
	private int iSize_;
	
	//constructor
	public Diamond()
	{
		iSize_ = MINSIZE;
	}
	/**
	 * Checking to see that the size is within the range.
	 * @param iSize
	 */
	public void setSize(int iSize)
	{
		if ((iSize > MINSIZE) || (iSize <= MAXSIZE))
		{
			this.iSize_ = iSize;
		}
	}
	
	public String makeDiamond()
	{
		String sDiamond = "";
		//build top half of diamond
		for (int row=1; row<=iSize_; row++)
		{
			
			//spaces
			for (int space=0; space<iSize_-row;space++)
			{
				sDiamond += SPACE;
			}
			//stars
			for (int star=0;star<=2*(row-1);star++)
			{
				sDiamond += ASTERISK;
			}
			sDiamond+= "\n";
		}
		//bottom half of diamond
		for (int row=iSize_; row>1; row--)
		{
			//spaces
			for (int space=iSize_-row; space>=0;space--)
			{
				sDiamond+= SPACE;
			}
			//stars
			for (int star=2*(row-1);star>1;star--)
			{
				sDiamond += ASTERISK;
			}
			sDiamond+= "\n";
		}
		return sDiamond;
	}

}
