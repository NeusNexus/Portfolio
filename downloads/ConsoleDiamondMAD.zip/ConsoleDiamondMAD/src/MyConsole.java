import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Class for performing general console input/output tasks
 * @author Kathleen Stewart
 * edited by Mike Dean.
 * @version 1.0 May 2013
 */
public class MyConsole {

	private BufferedReader console_;
	
	public BufferedReader getConsole() {
		return console_;
	}

	public void setConsole(BufferedReader console) {
		this.console_ = console;
	}

	/**
	 * Initialize console for input
	 */
	public MyConsole()
	{
		console_ = new BufferedReader(new InputStreamReader(
				System.in));
	}

	/**
	 * Prompt the user to continue processing
	 * @return true - continue, false - quit
	 */
	public Boolean keepGoing() {
		try {
			String sIn;
			System.out.print("Do you want to continue (Y/N)? ");
			sIn = console_.readLine();
			return (sIn.toUpperCase().startsWith("Y"));
		} catch (IOException e) {
			System.out.println(e.getMessage());
			return false;
		}
	}
	/**
	 * Method to take in the input size of the diamond 
	 * with some exception handling.
	 * @return
	 */
	public int inputSize()
	{
		int iInput = -1;
		String sIn;
		try {		
			System.out.print("Enter a size for the diamond (1-10): ");
			sIn = console_.readLine();
			iInput = Integer.parseInt(sIn);
		} catch (Exception e) {
			System.out.println("Invalid Input: " + e.getMessage());
		}
		return iInput;
	}
	
	public void outputDiamond(String sIn)
	{
		System.out.println(sIn);
	}
	/**
	 * Close the program with a friendly message
	 */
	public void exitProgram() {
		try {
			System.out.print("\nPress Enter to Exit.  Thanks for playing!");
			console_.readLine();
		} catch (IOException e) {
			e.getMessage();
		}
	}

}
