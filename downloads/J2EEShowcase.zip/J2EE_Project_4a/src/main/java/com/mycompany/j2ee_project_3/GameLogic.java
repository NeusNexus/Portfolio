/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.j2ee_project_3;

import com.mycompany.j2ee_project_4a.Guesses;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author J2EE
 */
@Stateless  // EJB can use JTA (Java Transaction API)
@Named
public class GameLogic {

    @Inject
    GlobalGuesses globalGuesses;

    @Inject
    GuessSession guessSession;

    @Inject
    GuessBean guessBean;

    @PersistenceContext
    EntityManager em;
    
    public GameLogic() {
    }

    public String doCheck() {

        // Check this current guess against the global to see if correct
        if (guessBean.getGuess() == globalGuesses.getNumberToGuess()) {
            // Guess is correct
            guessBean.setGuessResponse("Correct Guess");

            // Set other Bean values to show this person won
            globalGuesses.setName(guessSession.getName());
            
            // Add guess winner in DB...first make guess object
            Guesses guess = new Guesses();
            guess.setName(guessSession.getName());
            guess.setGuesscount((short) guessSession.getCount());
            guess.setGuessed((short) globalGuesses.getNumberToGuess());
            
            //Save the new object as a row in the table
            em.persist(guess);
           

        } else {
            //Guess is wrong
            guessBean.setGuessResponse("Wrong");
        }

        // Increment total number of guesses
        // This is for show of scope
        globalGuesses.incCount();
        guessSession.incCount();
        guessBean.incCount();

        logit.log("=================================");
        logit.log("GuessBean: Name:" + guessBean.getName() + " Guess:"+guessBean.getGuess()+ "  Count:" + guessBean.getCount() + " Response:" + guessBean.getGuessResponse());
        logit.log("guessSession: Name:" + guessSession.getName() +" Count:" + guessSession.getCount());
        logit.log("globalGuesses: " + globalGuesses.getName() + " Count:" + globalGuesses.getCount() + " Guess This:" + globalGuesses.getNumberToGuess());
        logit.log("=================================");

        return "PlayGame.xhtml";
    }
}
