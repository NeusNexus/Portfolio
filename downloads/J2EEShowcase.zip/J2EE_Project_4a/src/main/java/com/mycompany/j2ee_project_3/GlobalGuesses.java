package com.mycompany.j2ee_project_3;

import javax.inject.Named;
import javax.inject.Singleton;

@Singleton
@Named
public class GlobalGuesses {

    private int count = 0;
    private int numberToGuess = 7;
    private String name = "Russy from Singleton Bean";

    public GlobalGuesses() {
    }

    /**
     * @return the count
     */
    public int getCount() {
        return count;
    }

    /**
     * @param count the count to set
     */
    public void setCount(int count) {
        this.count = count;
    }

    public void incCount() {
        this.count++;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the numberToGuess
     */
    public int getNumberToGuess() {
        return numberToGuess;
    }

    /**
     * @param numberToGuess the numberToGuess to set
     */
    public void setNumberToGuess(int numberToGuess) {
        this.numberToGuess = numberToGuess;
    }

}
