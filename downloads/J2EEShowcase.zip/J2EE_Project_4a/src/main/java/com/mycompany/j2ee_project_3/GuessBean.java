package com.mycompany.j2ee_project_3;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

@RequestScoped
@Named
public class GuessBean {

    @Inject
    GlobalGuesses globalGuesses;

    @Inject
    GuessSession game;

    private int count = 0;
    private int guess = 0;
    private String name = "Russy2";
    private String guessResponse = "no response";

    public GuessBean() {
    }

    /**
     * @return the count
     */
    public int getCount() {
        return count;
    }

    /**
     * @param count the count to set
     */
    public void setCount(int count) {
        this.count = count;
    }
    
    public void incCount() {
        this.count++;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the guess
     */
    public int getGuess() {
        return guess;
    }

    /**
     * @param guess the guess to set
     */
    public void setGuess(int guess) {
        this.guess = guess;
    }

    /**
     * @return the guessResponse
     */
    public String getGuessResponse() {
        return guessResponse;
    }

    /**
     * @param guessResponse the guessResponse to set
     */
    public void setGuessResponse(String guessResponse) {
        this.guessResponse = guessResponse;
    }

}
