package com.live.dean.mike.letsnfctag;


import java.io.Serializable;

/**
 * Created by Mike on 2014-05-27.
 */

public class GameData implements Serializable {

    private static final long serialVersionUID = 1L;

    public static final Integer serverport = 54654;



    /**
     *
     *
     *Commands:
     *
     *
     *  [Game Data] with embedded action:
     *  	- Register
     *     	- Tag Collection
     *     	- Tag Reply
     *
     */

    public enum netCommands {
        No_Command, Register, Tag_Collection, Tag_Reply
    }


    // The command, one of enumerations above
    public netCommands comm;

    private String Player_Name;
    private String Player_ID;
    private String Tag_ID;

    public GameData (netCommands comm) {
        this.comm = comm;
    }

    public GameData (GameData n) {
        this.comm = n.comm;
    }

    public netCommands getComm() {
        return comm;
    }

    public String toString() {
        return comm.name();
    }

    String getPlayer_Name() {
        return Player_Name;
    }

    void setPlayer_Name(String player_Name) {
        Player_Name = player_Name;
    }

    String getPlayer_ID() {
        return Player_ID;
    }

    void setPlayer_ID(String player_ID) {
        Player_ID = player_ID;
    }

    String getTag_ID() {
        return Tag_ID;
    }

    void setTag_ID(String tag_ID) {
        Tag_ID = tag_ID;
    }

}





