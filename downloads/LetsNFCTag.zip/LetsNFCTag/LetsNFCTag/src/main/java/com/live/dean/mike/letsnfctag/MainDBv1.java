package com.live.dean.mike.letsnfctag;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by Mike on 2014-05-08.
 */
public class MainDBv1 extends SQLiteOpenHelper {

    public static final int DATABASE_EDITION = 1;
    public static final String DATABASE_LABEL = "LNT_DB.db";

    public MainDBv1(Context context) {
        super(context, "DB_Name", null, 10);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        //Creating Tag Table +  Adding Data


        Log.d("com.live.dean.mike.letsnfctag", String.valueOf(db));

        db.execSQL("CREATE TABLE TAG (TID VARCHAR(256) PRIMARY KEY NOT NULL, POINT_VAL INTEGER )");

        db.execSQL("INSERT INTO TAG(TID,POINT_VAL) VALUES('T1',10 )");

        db.execSQL("INSERT INTO TAG(TID,POINT_VAL) VALUES('T2',15 )");

        db.execSQL("INSERT INTO TAG(TID,POINT_VAL) VALUES('T3',25 )");

        db.execSQL("INSERT INTO TAG(TID,POINT_VAL) VALUES('T4',40 )");

        db.execSQL("INSERT INTO TAG(TID,POINT_VAL) VALUES('T5',60 )");

        db.execSQL("INSERT INTO TAG(TID,POINT_VAL) VALUES('T6',85 )");

        db.execSQL("INSERT INTO TAG(TID,POINT_VAL) VALUES('T7',115 )");

        //Creating Player Table + adding sample data

        db.execSQL("CREATE TABLE PLAYER (PID VARCHAR(256) PRIMARY KEY NOT NULL, NAME VARCHAR(256) )");

        db.execSQL("INSERT INTO PLAYER(PID,NAME) VALUES('10.25.228.1','Mike Dean' )");

        // Create Collected Table + adding sample data

        db.execSQL("CREATE TABLE COLLECTED (TID VARCHAR(256) PRIMARY KEY NOT NULL, PID VARCHAR(256), FOREIGN KEY (TID) REFERENCES " +
        "TAG(TID)," +" FOREIGN KEY (PID) REFERENCES " +"PLAYER(PID) )");
        db.execSQL("INSERT INTO COLLECTED(TID,PID) VALUES('T7','10.25.228.1' )");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVer, int newVer) {

        db.execSQL("DROP TABLE IF EXISTS TAG");
        db.execSQL("DROP TABLE IF EXISTS PLAYER");
        db.execSQL("DROP TABLE IF EXISTS COLLECTED");
        onCreate(db);
    }
}
