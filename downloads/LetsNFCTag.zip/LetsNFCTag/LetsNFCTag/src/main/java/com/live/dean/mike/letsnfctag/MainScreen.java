package com.live.dean.mike.letsnfctag;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;





public class MainScreen extends ActionBarActivity {

    public final static String Player_Name = "com.live.dean.mike.letsnfctag.PLAYER";
    public final static String Server = "com.live.dean.mike.letsnfctag.Server";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen);



    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_screen, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Called when the user clicks the Send button
     */
    public void sendPlayer(View view) {

        //Client button actions

        Intent intent = new Intent(this, Client.class);
        EditText editText = (EditText) findViewById(R.id.enter_Player);
        EditText editText2 = (EditText) findViewById(R.id.enter_ServerIP);
        String player = editText.getText().toString();
        String server = editText2.getText().toString();
        intent.putExtra(Player_Name, player);
        intent.putExtra(Server, server);

        Log.d("com.live.dean.mike.letsnfctag", "Server has been set as: " + server);

        if (server != null)
        {
            startActivity(intent);
            //blank.start();
        }

    }

    public void sendServer(View view) {

        //Server button actions

        Intent intent = new Intent(this, Server.class);
        Server MyServer = new Server();
        (new Thread(MyServer)).start();
        startActivity(intent);
    }
}
