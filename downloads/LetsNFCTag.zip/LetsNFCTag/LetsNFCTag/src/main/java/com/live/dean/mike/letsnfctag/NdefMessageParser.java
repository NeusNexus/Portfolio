package com.live.dean.mike.letsnfctag;

import java.util.ArrayList;
import java.util.List;

import com.live.dean.mike.letsnfctag.record.ParsedNdefRecord;
import com.live.dean.mike.letsnfctag.record.TextRecord;

import android.app.Activity;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * Created by Mike on 2014-05-04.
 */
public class NdefMessageParser {

    // Utility class
    private NdefMessageParser() {

    }

    /**
     * Parse an NdefMessage
     */
    public static List<ParsedNdefRecord> parse(NdefMessage message) {
        return getRecords(message.getRecords());
    }

    public static List<ParsedNdefRecord> getRecords(NdefRecord[] records) {
        // Starts an arraylist of type ParsedNdefRecord and add to it if the record is text.
        List<ParsedNdefRecord> elements = new ArrayList<ParsedNdefRecord>();
        for (final NdefRecord record : records) {
            if (TextRecord.isText(record)) elements.add(TextRecord.parse(record));
            else {
                elements.add(new ParsedNdefRecord() {
                    @Override
                    public View getView(Activity activity, LayoutInflater inflater, ViewGroup parent, int offset) {
                        TextView text = (TextView) inflater.inflate(R.layout.tag_text, parent, false);
                        text.setText(new String(record.getPayload()));
                        return text;
                    }

                });
            }
        }
        return elements;
    }
}
