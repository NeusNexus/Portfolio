package com.live.dean.mike.letsnfctag;

import android.app.Activity;
//import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;

import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Observable;
import java.util.Observer;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Created by Mike on 2014-05-08.
 */
public class Server extends Activity implements Runnable, Observer {

    EditText DB_Resp;
    TextView DBIsActive;


    Socket sock = null;
    ServerSocket serverSocket = null;

    private boolean more = true;
    private final Integer serverport = com.live.dean.mike.letsnfctag.GameData.serverport;

    ArrayList<NetWriter> clients = new ArrayList<NetWriter>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_server);
        Log.d("com.live.dean.mike.letsnfctag", "On create of the db view that shows everything in the database");

        //Intent intent = getIntent();
        //String Player = intent.getStringExtra(MainScreen.Player_Name);
        //TextView player = (TextView) findViewById(R.id.Player);
        //player.setText(Player);


        // get reference to the views
        DB_Resp = (EditText) findViewById(R.id.DBResp);
        DBIsActive = (TextView) findViewById(R.id.DBIsActive);

        // check if you are connected or not
        DBIsActive.setBackgroundColor(0xFF00CC00);
        DBIsActive.setText("DB Activated");

        // call AsynTask to perform network operation on separate thread
        new DB_RUN().execute("Start Connection");
    }

    @Override
    public void update(Observable observable, Object event) {

        if (event instanceof GameData) {
            com.live.dean.mike.letsnfctag.GameData e = new GameData((GameData) event);

            switch (e.getComm()) {
                case Register:
                    // In this case, The IP address of the client(PID) and the client's name (Name) are
                    // going to be added to the Player Table in the Database.
                    Log.d("com.live.dean.mike.letsnfctag", "Client has registered");
                    break;
                case Tag_Collection:
                    // In this case, the Tag ID (TID) and the IP address of the client(PID) are going
                    // to be added to the Collected Table in the Database.
                    Log.d("com.live.dean.mike.letsnfctag", "A tag has been collected");
                    break;
                case Tag_Reply:
                    // In this case, a Tag has been collected and a message is going to be sent out
                    // to all clients who are playing the game.
                    for (NetWriter w : clients) {
                        w.sendThisMsgOnQueue(e);
                        Log.d("com.live.dean.mike.letsnfctag", "Sending tag Reply to: " + w.getIP());
                    }
                case No_Command:
                    break;
                // No command has been sent through the network.
                default:
                    break;

            }

        }
    }

    @Override
    public void run() {

        try {
            serverSocket = new ServerSocket(serverport.intValue());
            Log.d("com.live.dean.mike.letsnfctag", "listening/Getting on port: "
                    + serverSocket.getLocalPort());
        } catch (java.io.IOException e) {
            e.printStackTrace();
        }

        if (serverSocket == null) {
            return;
        }

        while (more) {
            Log.d("com.live.dean.mike.letsnfctag", "Waiting for clients.....");
            try {
                sock = serverSocket.accept();
            } catch (IOException e) {
                e.printStackTrace();
            }


            // Launch Reader Thread to handle this new client
            NetReader reader = new NetReader(sock);
            //reader.start();
            (new Thread(reader)).start();
            reader.addObserver(this);

            NetWriter writer = new NetWriter(sock);
            writer.start();

            clients.add(writer);
            Log.d("com.live.dean.mike.letsnfctag", "Writer Array Size: " + clients.size());
            for (NetWriter w : clients) {
                Log.d("com.live.dean.mike.letsnfctag", " :: " + w.getIP());
            }

        }

        try {
            serverSocket.close();
        } catch (IOException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE,
                    null, ex);
        }

    }

    private class DB_RUN extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... msg) {

            String TagT = getString(R.string.TagT);
            String PlayT = getString(R.string.PlayT);
            String CollT = getString(R.string.CollT);
            String result = "";
            String result2 = "";
            String result3 = "";

            MainDBv1 DB_Tables = new MainDBv1(Server.this);


            //dump all rows
            {
                SQLiteDatabase db = DB_Tables.getReadableDatabase();
                Log.d("com.live.dean.mike.letsnfctag", "This is where the database should be read in");

                // Define a projection that specifies which columns from the database
                // you will actually use after this query.
                String[] projection = {"TID, POINT_VAL"};
                String[] projection2 = {"PID, NAME"};
                String[] projection3 = {"TID, PID"};

                // How you want the results sorted in the resulting Cursor
                //String sortOrder = "TID";   // sort by ascending TID
                //String sortOrder2 = "PID";

                Cursor c = db.query(
                        "TAG",  // The table to query
                        projection,                               // The columns to return
                        null,                                // The columns for the WHERE clause
                        null,                            // The values for the WHERE clause
                        null,                                     // don't group the rows
                        null,                                     // don't filter by row groups
                        null                                 // The sort order
                );

                Cursor p = db.query(
                        "PLAYER",  // The table to query
                        projection2,                               // The columns to return
                        null,                                // The columns for the WHERE clause
                        null,                            // The values for the WHERE clause
                        null,                                     // don't group the rows
                        null,                                     // don't filter by row groups
                        null                                 // The sort order
                );

                Cursor g = db.query(
                        "COLLECTED",  // The table to query
                        projection3,                               // The columns to return
                        null,                                // The columns for the WHERE clause
                        null,                            // The values for the WHERE clause
                        null,                                     // don't group the rows
                        null,                                     // don't filter by row groups
                        null                                 // The sort order
                );
                Log.d("com.live.dean.mike.letsnfctag", "This is where the queries should have been created with the cursors");

                Object o = null;  //object returned from column in DB
                String key = "";
                String value = "";
                String key2 = "";
                String value2 = "";
                String key3 = "";
                String value3 = "";


                for (; c.moveToNext(); ) {
                    int colCount = c.getColumnCount();
                    Log.d("com.live.dean.mike.letsnfctag", "colCount=" + String.valueOf(colCount));

                    for (int i = 0; i < colCount; ++i) {
                        Log.d("com.live.dean.mike.letsnfctag", "i=" + i);
                        switch (c.getType(i)) {
                            case Cursor.FIELD_TYPE_INTEGER:
                                key = c.getColumnName(i);
                                value = String.valueOf(c.getInt(i));
                                break;
                            case Cursor.FIELD_TYPE_STRING:
                                key = c.getColumnName(i);
                                value = c.getString(i);
                                break;
                        }
                        Log.d("com.live.dean.mike.letsnfctag", " Tag Table key=" + key + " value=" + value);
                        result += "key=" + key + " value=" + value + "\n";

                        Log.d("com.live.dean.mike.letsnfctag", "Next Column");
                        result += "\n";
                    }
                }

                for (; p.moveToNext(); ) {
                    int colCount2 = p.getColumnCount();

                    Log.d("com.live.dean.mike.letsnfctag", "colCount2= " + String.valueOf(colCount2));

                    for (int j = 0; j < colCount2; ++j) {
                        switch (p.getType(j)) {
                            case Cursor.FIELD_TYPE_INTEGER:
                                key2 = p.getColumnName(j);
                                value2 = String.valueOf(p.getInt(j));
                                break;
                            case Cursor.FIELD_TYPE_STRING:
                                key2 = p.getColumnName(j);
                                value2 = p.getString(j);
                                break;
                        }
                        Log.d("com.live.dean.mike.letsnfctag", "Player Table Key=" + key2 + " Value=" + value2);
                        result2 += "key=" + key2 + " value=" + value2 + "\n";
                        Log.d("com.live.dean.mike.letsnfctag", "Next Column");
                        result2 += "\n";
                    }
                }
                for (; g.moveToNext(); ) {
                    int colCount3 = g.getColumnCount();

                    Log.d("com.live.dean.mike.letsnfctag", "colCount3= " + String.valueOf(colCount3));

                    for (int k = 0; k < colCount3; ++k) {
                        switch (g.getType(k)) {
                            case Cursor.FIELD_TYPE_INTEGER:
                                key3 = g.getColumnName(k);
                                value3 = String.valueOf(g.getInt(k));
                                break;
                            case Cursor.FIELD_TYPE_STRING:
                                key3 = g.getColumnName(k);
                                value3 = g.getString(k);
                                break;
                        }
                        Log.d("com.live.dean.mike.letsnfctag", "Collected Table Key=" + key3 + " Value=" + value3);
                        result3 += "key=" + key3 + " value=" + value3 + "\n";
                        Log.d("com.live.dean.mike.letsnfctag", "Next Column");
                        result3 += "\n";
                    }
                }
            }
            Log.d("com.live.dean.mike.letsnfctag", "Result= " + result + " Result2= " + result2 + "Result3=" + result3);

            return TagT + "\n" + result + PlayT + "\n" + result2 + CollT + "\n" + result3;


        }  // onPostExecute displays the results of the AsyncTask.

        @Override
        protected void onPostExecute(String result) {
            Toast.makeText(getBaseContext(), "DONE", Toast.LENGTH_LONG).show();
            DB_Resp.setText(result);
            Log.d("com.live.dean.mike.letsnfctag", result);
        }

    }
}



