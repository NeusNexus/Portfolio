﻿Public Class frmMorse
    'Program: Morse Code Convertor
    'Prject name: ExamProgramMorseCode
    'Programmer: Mike Dean
    'Date: December 12,2013
    'Description: A program to convert a message into morse code.

    Sub GetInput(ByRef Mess As String)
        'Get Input from user and store in mess variable
        'Remove all punctuation from input and give back to main event.
            Mess = txtOrigin.Text.ToUpper
            Mess = Mess.Replace("'", "")
            Mess = Mess.Replace(".", "")
            Mess = Mess.Replace("?", "")
            Mess = Mess.Replace(",", "")
            Mess = Mess.Replace(" ", "")
            For i As Integer = 0 To Mess.Length - 1
                If Not (Mess.Substring(i, 1)) Like "[ABCDEFGHIJKLMNOPQRSTUVWXYZ]" Then
                    MessageBox.Show("You have not entered a word or a phrase, please enter a word or phrase", "Incorrect input")
                    Mess = ""
                    txtConvert.Text = "Error"
                    txtOrigin.Focus()
                    Exit Sub
                Else
                    Mess = Mess
                End If
            Next
    End Sub

    Function Convert(ByRef mess As String) As String
        'Replace alphabet contained in message and replace 
        'with corresponding morse code from the text file.
        'return converted message to main event.
        Dim Morse() As String = IO.File.ReadAllLines("MorseCode.txt")
        mess = mess.Replace("A", Morse(0))
        mess = mess.Replace("B", Morse(1))
        mess = mess.Replace("C", Morse(2))
        mess = mess.Replace("D", Morse(3))
        mess = mess.Replace("E", Morse(4))
        mess = mess.Replace("F", Morse(5))
        mess = mess.Replace("G", Morse(6))
        mess = mess.Replace("H", Morse(7))
        mess = mess.Replace("I", Morse(8))
        mess = mess.Replace("J", Morse(9))
        mess = mess.Replace("K", Morse(10))
        mess = mess.Replace("L", Morse(11))
        mess = mess.Replace("M", Morse(12))
        mess = mess.Replace("N", Morse(13))
        mess = mess.Replace("O", Morse(14))
        mess = mess.Replace("P", Morse(15))
        mess = mess.Replace("Q", Morse(16))
        mess = mess.Replace("R", Morse(17))
        mess = mess.Replace("S", Morse(18))
        mess = mess.Replace("T", Morse(19))
        mess = mess.Replace("U", Morse(20))
        mess = mess.Replace("V", Morse(21))
        mess = mess.Replace("W", Morse(22))
        mess = mess.Replace("X", Morse(23))
        mess = mess.Replace("Y", Morse(24))
        mess = mess.Replace("Z", Morse(25))
        Return mess
    End Function

    Sub Display(Cmessage As String)
        'Display Converted message in below textbox.
        txtConvert.Text = Cmessage
    End Sub

    Private Sub btnConvert_Click(sender As Object, e As EventArgs) Handles btnConvert.Click
        'get and verify input from user and convert message into morse code.
        Dim mess As String = ""
        Dim CMessage As String
        GetInput(mess)
            CMessage = Convert(mess)
            Display(CMessage)
    End Sub
End Class
