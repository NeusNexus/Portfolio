﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPdrome
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblInput = New System.Windows.Forms.Label()
        Me.txtInput = New System.Windows.Forms.TextBox()
        Me.btnPDrome = New System.Windows.Forms.Button()
        Me.txtOutput = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'lblInput
        '
        Me.lblInput.AutoSize = True
        Me.lblInput.Location = New System.Drawing.Point(72, 9)
        Me.lblInput.Name = "lblInput"
        Me.lblInput.Size = New System.Drawing.Size(115, 13)
        Me.lblInput.TabIndex = 1
        Me.lblInput.Text = "Enter a word or Phrase"
        '
        'txtInput
        '
        Me.txtInput.Location = New System.Drawing.Point(47, 42)
        Me.txtInput.Name = "txtInput"
        Me.txtInput.Size = New System.Drawing.Size(176, 20)
        Me.txtInput.TabIndex = 0
        '
        'btnPDrome
        '
        Me.btnPDrome.Location = New System.Drawing.Point(77, 81)
        Me.btnPDrome.Name = "btnPDrome"
        Me.btnPDrome.Size = New System.Drawing.Size(110, 23)
        Me.btnPDrome.TabIndex = 2
        Me.btnPDrome.Text = "&Palindrome Check"
        Me.btnPDrome.UseVisualStyleBackColor = True
        '
        'txtOutput
        '
        Me.txtOutput.Location = New System.Drawing.Point(104, 125)
        Me.txtOutput.Multiline = True
        Me.txtOutput.Name = "txtOutput"
        Me.txtOutput.Size = New System.Drawing.Size(46, 19)
        Me.txtOutput.TabIndex = 3
        '
        'frmPdrome
        '
        Me.AcceptButton = Me.btnPDrome
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(260, 156)
        Me.Controls.Add(Me.txtOutput)
        Me.Controls.Add(Me.btnPDrome)
        Me.Controls.Add(Me.lblInput)
        Me.Controls.Add(Me.txtInput)
        Me.Name = "frmPdrome"
        Me.Text = "Is it a Palindrome?"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblInput As System.Windows.Forms.Label
    Friend WithEvents txtInput As System.Windows.Forms.TextBox
    Friend WithEvents btnPDrome As System.Windows.Forms.Button
    Friend WithEvents txtOutput As System.Windows.Forms.TextBox

End Class
