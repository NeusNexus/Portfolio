﻿Public Class frmPdrome
    'Program: Is it a Palindrome?
    'Prject name: Project3A
    'Programmer: Mike Dean
    'Date: December 3,2013
    'Description: A program to determine if a word or phrase is a palindrome.

    Sub GetInput(ByRef word As String)
        word = txtInput.Text.ToUpper
        word = word.Replace(" ", "")
        word = word.Replace("?", "")
        word = word.Replace(".", "")
        word = word.Replace(",", "")
        word = word.Replace("'", "")
    End Sub

    Sub Verify(ByRef Input As String)
        For i As Integer = 0 To Input.Length - 1
            If Not (Input.Substring(i, 1)) Like "[ABCDEFGHIJKLMNOPQRSTUVWXYZ]" Then
                MessageBox.Show("You have not entered a word or a phrase, please enter a word or phrase", "Incorrect input")
                Input = ""
                Exit Sub
            Else
                Input = Input
            End If
        Next
    End Sub

    Function IsPalindrome(Input As String) As Boolean

        Dim n As Integer = Input.Length
        Dim drome As Boolean
        For i As Integer = 0 To (n - 1)
            If (Input.Substring(i, 1) <> Input.Substring(n - i - 1, 1)) Then
                drome = False
            Else
                drome = True
            End If
        Next
        Return drome
    End Function

    Sub Display(answer As Boolean)
        If answer = True Then
            txtOutput.Text = "YES"
        Else
            txtOutput.Text = "NO"
        End If
    End Sub

    Private Sub btnPDrome_Click(sender As Object, e As EventArgs) Handles btnPDrome.Click
        Dim word As String = ""
        Dim answer As Boolean
        GetInput(word)
        Verify(word)
        answer = IsPalindrome(word)
        If IsNumeric(txtInput.Text) Then
            txtOutput.Text = ""
        ElseIf word = "" Then
            txtOutput.Text = ""
            MessageBox.Show("Cannot determine if Palindrome", "Error")
        Else
            Display(answer)
        End If
    End Sub
End Class
